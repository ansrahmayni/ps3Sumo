#include "aktuator.h"

const int turn_90 = 180;
const int normal = 150;
const int stab = 220;

#define MAJU    0b000000010000
#define MUNDUR  0b000000100000
#define KANAN   0b000001000000
#define KIRI    0b000010000000

#define TUBRUK  0b000100000000
#define SELIPR  0b001000000000
#define SELIPL  0b010000000000
#define BACK    0b100000000000

void maju(int speed){
  setMotor(speed, speed);
}

void mundur(int speed){
  setMotor(-speed, -speed);
}

void kanan(int speed){
  setMotor(200, speed);
}

void puterR(int speed){
  setMotor(speed, -speed);
}

void kiri(int speed){
  setMotor(speed, 200);
}

void puterL(int speed){
  setMotor(-speed, speed);
}

void tubruk(int speed){
  setMotor(speed, speed);
}

void berenti(){
  setMotor(0, 0);
}

void selipR(){
  puterR(255);

  maju(200);
  delay(normal);

  puterL(255);
}

void selipL(){
  puterL(255);

  maju(200);
  delay(normal);

  puterR(255); 
}

void back(){
  puterR(255);

  maju(200);
  delay(stab);

  puterL(255);
}

void handlePS3() {

  // failsafe
  if (!Ps3.isConnected()) {
    berenti();
    return;
  }

  uint16_t tombol = 0;

  // Mapping tombol PS3 -> bitmask
  if (Ps3.data.button.up)       tombol |= MAJU;
  if (Ps3.data.button.down)     tombol |= MUNDUR;
  if (Ps3.data.button.right)    tombol |= KANAN;
  if (Ps3.data.button.left)     tombol |= KIRI;

  if (Ps3.data.button.cross)    tombol |= TUBRUK;
  if (Ps3.data.button.circle)   tombol |= SELIPR;
  if (Ps3.data.button.square)   tombol |= SELIPL;
  if (Ps3.data.button.triangle) tombol |= BACK;

  // Debug
  Serial.print("Buttons: ");
  Serial.println(tombol, BIN);

  if (tombol == MAJU) {
    Serial.println("majuu");
    maju(200);

  } else if (tombol == MUNDUR) {
    Serial.println("mundurr");
    mundur(200);

  } else if (tombol == KANAN) {
    Serial.println("nganan");
    kanan(120);

  } else if (tombol == KIRI) {
    Serial.println("ngiri");
    kiri(120);

  } else if (tombol == TUBRUK) {
    Serial.println("gass");
    tubruk(255);

  } else if (tombol == SELIPR) {
    Serial.println("nyelip kanan");
    selipR();

  } else if (tombol == SELIPL) {
    Serial.println("nyelip kiri");
    selipL();

  } else if (tombol == BACK) {
    Serial.println("back stabb");
    back();

  } else {
    berenti();
  }
}